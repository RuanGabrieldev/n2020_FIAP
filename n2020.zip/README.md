# n2020

Projeto em desenvolvimento para avaliação do primeiro semestre do curso de Sistemas de Informação da FIAP, com o objetivo de criar um ChatBot que posasa sanar problemas causados pelo Covid-19 por conta do isolamento social. 

Trabalho está sendo realizado em grupo, com os integrantes:
- https://github.com/RuanGabrieldev
- https://github.com/GustavoNovaes-BR
- https://github.com/laisfe
- https://github.com/marcioluiz0391
- https://github.com/pedromsouza99

## Andamento do projeto (TELAS)

- Telas de apresentação do App
![alt text](https://lh3.googleusercontent.com/pw/ACtC-3dKwSDQWkMkNlYc9pg4QkoImCmS9CsVo8KL0A07e_JtvpXQ5-2mJqfRsHXTa62EALVzNflPCkdgqe_liWGcymw8aPgCxOYy6ic7BwuMhc4KzPuiW-M5qJoOS9FIIHgUMiEnNHDj8qTE6UL5dtlSzGVb=w1050-h659-no?authuser=0)
